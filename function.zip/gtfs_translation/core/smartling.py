import asyncio
import json
import logging
import random
import time

import httpx

from gtfs_translation.config import to_smartling_code
from gtfs_translation.core.translator import Translator


class SmartlingTranslator(Translator):
    _token: str | None = None
    _token_expiry: float = 0

    def __init__(self, user_id: str, user_secret: str, account_uid: str):
        self.user_id = user_id
        self.user_secret = user_secret
        self.account_uid = account_uid
        self.client = httpx.AsyncClient(timeout=10.0)
        self._token_lock = asyncio.Lock()

    async def _get_token(self) -> str:
        async with self._token_lock:
            now = time.time()
            if self._token and now < self._token_expiry:
                return self._token

            url = "https://api.smartling.com/auth-api/v2/authenticate"
            payload = {"userIdentifier": self.user_id, "userSecret": self.user_secret}

            resp = await self.client.post(url, json=payload)
            resp.raise_for_status()
            data = resp.json()

            self._token = data["response"]["data"]["accessToken"]
            # Refresh 1 minute before expiry (expiresIn is in seconds)
            expires_in = data["response"]["data"]["expiresIn"]
            self._token_expiry = now + expires_in - 60

            return self._token

    async def translate_batch(
        self, texts: list[str], target_langs: list[str]
    ) -> dict[str, list[str | None]]:
        """
        Translates a batch of texts using Smartling MT API for multiple languages.
        Converts GTFS language codes to Smartling codes before calling the API.
        Returns results keyed by original GTFS language codes.
        """
        if not texts or not target_langs:
            return {lang: [] for lang in target_langs}

        # Convert to Smartling codes for API calls
        smartling_langs = [to_smartling_code(lang) for lang in target_langs]

        results = await asyncio.gather(
            *[self._translate_batch_single_lang(texts, lang) for lang in smartling_langs]
        )
        # Return with original GTFS codes as keys
        return dict(zip(target_langs, results, strict=True))

    async def _translate_batch_single_lang(
        self, texts: list[str], target_lang: str
    ) -> list[str | None]:
        """
        Translates a batch of texts using Smartling MT API for a single target language.
        Retry on 401 once (token expiry race condition).
        Retry on 429 with randomized exponential backoff (1s to 30s).
        """
        backoff_seconds = 1.0
        max_backoff = 30.0
        max_attempts = 5
        last_error: httpx.HTTPStatusError | None = None

        for attempt in range(max_attempts):
            try:
                return await self._do_translate_batch(texts, target_lang)
            except httpx.HTTPStatusError as e:
                last_error = e
                status_code = e.response.status_code
                if status_code == 401:
                    # Force refresh
                    self._token = None
                    continue
                if status_code == 429 and attempt < max_attempts - 1:
                    sleep_for = random.uniform(0, backoff_seconds)
                    logging.warning(
                        "Smartling MT API rate limited (429) for lang %s. Backing off for %.2fs.",
                        target_lang,
                        sleep_for,
                    )
                    await asyncio.sleep(sleep_for)
                    backoff_seconds = min(max_backoff, backoff_seconds * 2)
                    continue
                raise e

        if last_error is not None:
            raise httpx.HTTPStatusError(
                f"Smartling MT API rate limit retry attempts exceeded for lang {target_lang}",
                request=last_error.request,
                response=last_error.response,
            )

        raise RuntimeError("Smartling MT API retry loop exited unexpectedly")

    async def _do_translate_batch(self, texts: list[str], target_lang: str) -> list[str | None]:
        token = await self._get_token()

        # MT Router API handles multiple items
        url = f"https://api.smartling.com/mt-router-api/v2/accounts/{self.account_uid}/smartling-mt"

        headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

        # Use the string index as the key to ensure order mapping
        payload = {
            "sourceLocaleId": "en",
            "targetLocaleId": target_lang,
            "items": [{"key": str(i), "sourceText": text} for i, text in enumerate(texts)],
        }

        try:
            # The MT API can handle up to 1000 items, which is likely plenty for our alerts.
            # If we ever exceed this, we'd need to chunk the texts here.
            resp = await self.client.post(url, headers=headers, json=payload)
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            logging.error(
                "Smartling MT API error: %s - %s", e.response.status_code, e.response.text
            )
            raise e
        except Exception as e:
            logging.exception("Unexpected error calling Smartling MT API")
            raise e

        data = resp.json()
        # Response format:
        # { "response": { "data": { "items": [ { "key": "0", "translationText": "..." }, ... ] } } }
        items = data["response"]["data"]["items"]

        translations_by_key = {
            item["key"]: item["translationText"]
            for item in items
            if "key" in item and "translationText" in item
        }
        translations: list[str | None] = []
        for index in range(len(texts)):
            key = str(index)
            translation = translations_by_key.get(key)
            if translation is None:
                logging.warning(
                    "Smartling MT API missing item for lang %s key %s",
                    target_lang,
                    key,
                )
            translations.append(translation)
        return translations

    async def close(self) -> None:
        await self.client.aclose()


class SmartlingJobBatchesTranslator(SmartlingTranslator):
    always_translate_all: bool = True

    def __init__(
        self,
        user_id: str,
        user_secret: str,
        project_id: str,
        source_uri: str,
        job_name_template: str = "GTFS Alerts Translation",
    ):
        # We don't need account_uid for Job Batches V2
        super().__init__(user_id, user_secret, "")
        self.project_id = project_id
        self.source_uri = source_uri
        self.job_name_template = job_name_template

    async def translate_batch(
        self, texts: list[str], target_langs: list[str]
    ) -> dict[str, list[str | None]]:
        """
        Translates a batch of texts using Smartling Job Batches V2 API.
        Converts GTFS language codes to Smartling codes before calling the API.
        Returns results keyed by original GTFS language codes.
        """
        if not texts or not target_langs:
            return {lang: [] for lang in target_langs}

        token = await self._get_token()
        headers = {"Authorization": f"Bearer {token}"}

        # Convert to Smartling codes for API calls
        smartling_langs = [to_smartling_code(lang) for lang in target_langs]

        job_uid = await self._get_or_create_job(headers, smartling_langs)
        batch_uid = await self._create_batch(headers, job_uid)
        await self._upload_file_to_batch(headers, batch_uid, texts, smartling_langs)
        await self._poll_batch_status(headers, batch_uid)

        results = await asyncio.gather(
            *[self._download_job_batch_translation(headers, lang) for lang in smartling_langs]
        )
        typed_results: list[list[str | None]] = [list(result) for result in results]
        # Use original GTFS codes for validation messages
        for orig_lang, translations in zip(target_langs, typed_results, strict=True):
            if len(translations) != len(texts):
                logging.warning(
                    "Smartling Job Batch missing translations for lang %s: expected %s got %s",
                    orig_lang,
                    len(texts),
                    len(translations),
                )
        # Return with original GTFS codes as keys
        return dict(zip(target_langs, typed_results, strict=True))

    async def _get_or_create_job(self, headers: dict[str, str], target_langs: list[str]) -> str:
        job_url = f"https://api.smartling.com/job-batches-api/v2/projects/{self.project_id}/jobs"
        job_payload = {
            "nameTemplate": self.job_name_template,
            "mode": "REUSE_EXISTING",
            "salt": "RANDOM_ALPHANUMERIC",
            "targetLocaleIds": target_langs,
        }
        resp = await self.client.post(job_url, headers=headers, json=job_payload)
        resp.raise_for_status()
        res: str = resp.json()["response"]["data"]["translationJobUid"]
        return res

    async def _create_batch(self, headers: dict[str, str], job_uid: str) -> str:
        batch_url = (
            f"https://api.smartling.com/job-batches-api/v2/projects/{self.project_id}/batches"
        )
        batch_payload = {
            "authorize": True,
            "translationJobUid": job_uid,
            "fileUris": [self.source_uri],
        }
        resp = await self.client.post(batch_url, headers=headers, json=batch_payload)
        resp.raise_for_status()
        res: str = resp.json()["response"]["data"]["batchUid"]
        return res

    async def _upload_file_to_batch(
        self, headers: dict[str, str], batch_uid: str, texts: list[str], target_langs: list[str]
    ) -> None:
        upload_url = f"https://api.smartling.com/job-batches-api/v2/projects/{self.project_id}/batches/{batch_uid}/file"
        file_content = json.dumps(texts).encode("utf-8")
        files = {
            "file": ("strings.json", file_content, "application/json"),
        }
        data = {
            "fileUri": self.source_uri,
            "fileType": "json",
        }
        # Multi-value field for localeIdsToAuthorize[]
        multi_data = [("localeIdsToAuthorize[]", lang) for lang in target_langs]
        form_data = list(data.items()) + multi_data

        # If we have both data and files, httpx uses multipart/form-data.
        resp = await self.client.post(
            upload_url, headers=headers, files={**files, **{k: (None, v) for k, v in form_data}}
        )
        resp.raise_for_status()

    async def _poll_batch_status(self, headers: dict[str, str], batch_uid: str) -> None:
        status_url = f"https://api.smartling.com/job-batches-api/v2/projects/{self.project_id}/batches/{batch_uid}"
        while True:
            resp = await self.client.get(status_url, headers=headers)
            resp.raise_for_status()
            batch_data = resp.json()["response"]["data"]
            status = batch_data.get("status")
            logging.info("Smartling Job Batch %s status: %s", batch_uid, status)
            if status == "COMPLETED":
                break
            if status == "FAILED":
                raise RuntimeError(f"Smartling Job Batch failed: {batch_data}")
            await asyncio.sleep(1)

    async def _download_job_batch_translation(
        self, headers: dict[str, str], lang: str
    ) -> list[str]:
        dl_url = (
            f"https://api.smartling.com/files-api/v2/projects/{self.project_id}/locales/{lang}/file"
        )
        dl_params = {"fileUri": self.source_uri, "retrievalType": "published"}
        resp = await self.client.get(dl_url, headers=headers, params=dl_params)
        resp.raise_for_status()
        result = resp.json()
        if not isinstance(result, list):
            raise ValueError(
                f"Expected JSON list response from Smartling Files API for {lang}, "
                f"got {type(result)}"
            )
        return result


class SmartlingFileTranslator(SmartlingTranslator):
    async def translate_batch(
        self, texts: list[str], target_langs: list[str]
    ) -> dict[str, list[str | None]]:
        """
        Translates a batch of texts using Smartling File Translation API.
        Converts GTFS language codes to Smartling codes before calling the API.
        Returns results keyed by original GTFS language codes.
        1. Upload file
        2. Start MT process
        3. Poll for status
        4. Download translated files (parallelized for target_langs)
        """
        if not texts or not target_langs:
            return {lang: [] for lang in target_langs}

        token = await self._get_token()
        headers = {"Authorization": f"Bearer {token}"}

        # Convert to Smartling codes for API calls
        smartling_langs = [to_smartling_code(lang) for lang in target_langs]

        # 1. Upload file
        upload_url = (
            f"https://api.smartling.com/file-translations-api/v2/accounts/{self.account_uid}/files"
        )
        file_content = json.dumps(texts).encode("utf-8")
        files = {
            "file": ("strings.json", file_content, "application/json"),
            "request": (None, json.dumps({"fileType": "json"}).encode("utf-8"), "application/json"),
        }

        resp = await self.client.post(upload_url, headers=headers, files=files)
        if resp.status_code == 400:
            logging.error("Smartling MT File API 400 Bad Request: %s", resp.text)
        resp.raise_for_status()
        file_uid = resp.json()["response"]["data"]["fileUid"]

        # 2. Start MT process
        mt_url = (
            f"https://api.smartling.com/file-translations-api/v2/accounts/"
            f"{self.account_uid}/files/{file_uid}/mt"
        )
        mt_payload = {"targetLocaleIds": smartling_langs, "sourceLocaleId": "en"}
        resp = await self.client.post(mt_url, headers=headers, json=mt_payload)
        resp.raise_for_status()
        mt_uid = resp.json()["response"]["data"]["mtUid"]

        # 3. Poll for status
        status_url = (
            f"https://api.smartling.com/file-translations-api/v2/accounts/"
            f"{self.account_uid}/files/{file_uid}/mt/{mt_uid}/status"
        )
        while True:
            resp = await self.client.get(status_url, headers=headers)
            resp.raise_for_status()
            status_data = resp.json()["response"]["data"]
            # File Translation API uses 'state', Job Batches uses 'status'
            status = status_data.get("status") or status_data.get("state")
            logging.info("Smartling MT File %s state: %s", mt_uid, status)
            if status == "COMPLETED":
                break
            if status == "FAILED":
                raise RuntimeError(f"Smartling MT File process failed: {status_data}")
            await asyncio.sleep(1)

        # 4. Download translated files
        async def download_lang(lang: str) -> list[str]:
            dl_url = (
                f"https://api.smartling.com/file-translations-api/v2/accounts/"
                f"{self.account_uid}/files/{file_uid}/mt/{mt_uid}/locales/{lang}/file"
            )
            resp = await self.client.get(dl_url, headers=headers)
            resp.raise_for_status()
            result = resp.json()
            if not isinstance(result, list):
                raise ValueError(
                    f"Expected JSON list response from Smartling MT File API for {lang}, "
                    f"got {type(result)}"
                )
            return result

        results = await asyncio.gather(*[download_lang(lang) for lang in smartling_langs])
        typed_results: list[list[str | None]] = [list(result) for result in results]
        # Return with original GTFS codes as keys
        return dict(zip(target_langs, typed_results, strict=True))
