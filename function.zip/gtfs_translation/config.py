import os


class Settings:
    def __init__(self) -> None:
        self.smartling_user_id = os.environ.get("SMARTLING_USER_ID", "")
        self.smartling_user_secret = os.environ.get("SMARTLING_USER_SECRET", "")
        self.smartling_user_secret_arn = os.environ.get("SMARTLING_USER_SECRET_ARN", "")
        self.smartling_account_uid = os.environ.get("SMARTLING_ACCOUNT_UID", "")
        self.smartling_project_id = os.environ.get("SMARTLING_PROJECT_ID", "")
        self.smartling_job_name_template = os.environ.get(
            "SMARTLING_JOB_NAME_TEMPLATE", "GTFS Alerts Translation"
        )
        self.source_url = os.environ.get("SOURCE_URL", "")
        self.destination_bucket_urls = os.environ.get("DESTINATION_BUCKET_URLS", "")
        self.target_languages = os.environ.get("TARGET_LANGUAGES", "es-LA")
        self.concurrency_limit = int(os.environ.get("CONCURRENCY_LIMIT", "20"))
        self.log_level = os.environ.get("LOG_LEVEL", "NOTICE")

    @property
    def destination_bucket_url_list(self) -> list[str]:
        return [url.strip() for url in self.destination_bucket_urls.split(",") if url.strip()]

    @property
    def target_lang_list(self) -> list[str]:
        return [lang.strip() for lang in self.target_languages.split(",") if lang.strip()]


settings = Settings()
